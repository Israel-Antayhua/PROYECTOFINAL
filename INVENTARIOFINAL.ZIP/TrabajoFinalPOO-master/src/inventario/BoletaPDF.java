package inventario;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class BoletaPDF {

    public void generarBoleta(Producto producto, int cantidad) {
        Document document = new Document();
        String ruta = "C:\\Users\\Melo\\Documents\\boletas";
        File directorio = new File(ruta);
        if (!directorio.exists() && !directorio.mkdirs()) {
            System.out.println("No se pudo crear la carpeta: " + ruta);
            return;
        }

        String nombreArchivo = "Boleta_" + System.currentTimeMillis() + ".pdf";

        try {
            PdfWriter.getInstance(document, new FileOutputStream(ruta + "\\" + nombreArchivo));
            document.open();

           
            Font fontTitle = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD);
            Font fontHeader = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
            Font fontContent = new Font(Font.FontFamily.HELVETICA, 12);
            Font fontFooter = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC);

           
            String logoPath = "src/imgs/logo.png";
            Image logo = Image.getInstance(logoPath);
            logo.scaleToFit(140, 60);
            logo.setAlignment(Element.ALIGN_CENTER);
            document.add(logo);

            
            Paragraph encabezado = new Paragraph("Boleta de Venta", fontTitle);
            encabezado.setAlignment(Element.ALIGN_CENTER);
            document.add(encabezado);
            document.add(new Paragraph(" "));

         
            PdfPTable headerTable = new PdfPTable(1);
            headerTable.setWidthPercentage(100);
            agregarCeldaTabla(headerTable, "Nombre de la Empresa: RYNPSAC", fontHeader);
            agregarCeldaTabla(headerTable, "Dirección: Calle LIMA 123", fontContent);
            agregarCeldaTabla(headerTable, "Teléfono: 929229312", fontContent);
            agregarCeldaTabla(headerTable, "RUC: 11238271623", fontContent);
            document.add(headerTable);
            document.add(new Paragraph(" "));

    
            PdfPTable fechaTable = new PdfPTable(2);
            fechaTable.setWidthPercentage(100);
            agregarCeldaTabla(fechaTable, "Fecha: " + new java.util.Date(), fontContent);
            agregarCeldaTabla(fechaTable, "Número de Boleta: " + System.currentTimeMillis(), fontContent);
            document.add(fechaTable);
            document.add(new Paragraph(" "));

            document.add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------"));
            document.add(new Paragraph(" "));

          
            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            agregarCeldaTabla(table, "Descripción", fontHeader);
            agregarCeldaTabla(table, "Cantidad", fontHeader);
            agregarCeldaTabla(table, "Precio Unitario", fontHeader);
            agregarCeldaTabla(table, "Precio Total", fontHeader);

            agregarCeldaTabla(table, producto.getNombre(), fontContent);
            agregarCeldaTabla(table, String.valueOf(cantidad), fontContent);
            agregarCeldaTabla(table, "$" + producto.getCostoVenta(), fontContent);
            agregarCeldaTabla(table, "$" + (cantidad * producto.getCostoVenta()), fontContent);
            document.add(table);
            document.add(new Paragraph(" "));

            
            document.add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------"));
            document.add(new Paragraph("Resumen de Compra:", fontHeader));
            document.add(new Paragraph("Subtotal: $" + (cantidad * producto.getCostoVenta()), fontContent));
            document.add(new Paragraph("IVA (18%): $" + (cantidad * producto.getCostoVenta() * 0.18), fontContent));
            document.add(new Paragraph("Total a Pagar: $" + (cantidad * producto.getCostoVenta() * 1.18), fontHeader));
            document.add(new Paragraph(" "));

        
            document.add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------"));
            document.add(new Paragraph("Agradecemos sinceramente su compra.", fontFooter));
            document.add(new Paragraph("Esperamos volver a servirle en el futuro.", fontFooter));
            document.add(new Paragraph("Gracias por confiar en RYNPSAC.", fontFooter));
            document.add(new Paragraph(" "));

        
            document.add(new Paragraph("----------------------------------------------------------------------------------------------------------------------------------"));
            document.add(new Paragraph("Política de Devoluciones: Se aceptan devoluciones dentro de 30 días.", fontFooter));
            document.add(new Paragraph("Para consultas: contacto@rynpsac.com", fontFooter));
            document.add(new Paragraph("Teléfono: 929229312", fontFooter));

            document.close();
            System.out.println("Boleta generada con éxito en: " + ruta + "\\" + nombreArchivo);
        } catch (DocumentException e) {
            System.err.println("Error en la creación del documento: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error al escribir el archivo: " + e.getMessage());
        }
    }

    private void agregarCeldaTabla(PdfPTable table, String texto, Font font) {
        PdfPCell cell = new PdfPCell(new Paragraph(texto, font));
        cell.setPadding(10);
        cell.setBorder(PdfPCell.BOX);
        table.addCell(cell);
    }
}
