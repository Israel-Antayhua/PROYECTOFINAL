package inventario;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JTable;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Actualizar {

    public void actualizarExcel(JTable t, String ruta) throws IOException {
        Workbook libro;
        FileInputStream archivoEntrada = null;

        try {
            archivoEntrada = new FileInputStream(ruta);
            libro = new HSSFWorkbook(archivoEntrada);
            Sheet hoja = libro.getSheetAt(0); 

            
            for (int i = hoja.getLastRowNum(); i > 0; i--) {
                hoja.removeRow(hoja.getRow(i));
            }

           
            Row headerRow = hoja.createRow(0);
            for (int c = 0; c < t.getColumnCount(); c++) {
                Cell celda = headerRow.createCell(c);
                celda.setCellValue(t.getColumnName(c));
            }

            
            for (int f = 0; f < t.getRowCount(); f++) {
                Row fila = hoja.createRow(f + 1);
                for (int c = 0; c < t.getColumnCount(); c++) {
                    Cell celda = fila.createCell(c);
                    Object value = t.getValueAt(f, c);
                    if (value instanceof Double) {
                        celda.setCellValue((Double) value);
                    } else if (value instanceof Float) {
                        celda.setCellValue((Float) value);
                    } else {
                        celda.setCellValue(String.valueOf(value));
                    }
                }
            }

            
            try (FileOutputStream archivoSalida = new FileOutputStream(ruta)) {
                libro.write(archivoSalida);
            }
        } finally {
            if (archivoEntrada != null) {
                archivoEntrada.close(); 
            }
            
        }
    }
}
