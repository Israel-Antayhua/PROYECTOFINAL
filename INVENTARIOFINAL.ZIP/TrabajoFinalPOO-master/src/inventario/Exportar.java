package inventario;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Exportar {
    
    public String exportarExcel(JTable t) throws IOException {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivo de Excel", "xls");
        chooser.setFileFilter(filter);
        chooser.setDialogTitle("Guardar Archivo");
        chooser.setAcceptAllFileFilterUsed(false);
        
        if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
            String ruta = chooser.getSelectedFile().toString().concat(".xls");
            File archivoXLS = new File(ruta);
            Workbook libro = new HSSFWorkbook();
            FileOutputStream archivo = null;

            try {
                if (archivoXLS.exists()) {
                    archivoXLS.delete(); 
                }
                archivoXLS.createNewFile();
                archivo = new FileOutputStream(archivoXLS);
                Sheet hoja = libro.createSheet("Productos");
                hoja.setDisplayGridlines(false);
                
               
                Row headerRow = hoja.createRow(0);
                for (int c = 0; c < t.getColumnCount(); c++) {
                    Cell celda = headerRow.createCell(c);
                    celda.setCellValue(t.getColumnName(c));
                }
                
                
                for (int f = 0; f < t.getRowCount(); f++) {
                    Row fila = hoja.createRow(f + 1); 
                    for (int c = 0; c < t.getColumnCount(); c++) {
                        Cell celda = fila.createCell(c);
                        Object value = t.getValueAt(f, c);
                        if (value instanceof Double) {
                            celda.setCellValue((Double) value);
                        } else if (value instanceof Float) {
                            celda.setCellValue((Float) value);
                        } else {
                            celda.setCellValue(String.valueOf(value));
                        }
                    }
                }
                
                libro.write(archivo);
                Desktop.getDesktop().open(archivoXLS); 
            } finally {
                if (archivo != null) {
                    archivo.close(); 
                }
            }

            return ruta; 
        }
        
        return null; 
    }
}
