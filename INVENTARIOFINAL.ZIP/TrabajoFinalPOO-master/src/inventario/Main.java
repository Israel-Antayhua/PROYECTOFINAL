package inventario;

public class Main {

    public static void main(String[] args) {
        Ingresar form = new Ingresar();
        form.setVisible(true);
    }
}
